let a=5
var b=10 // старый способ
const c = "123"
a=10
c = 27
console.log(c);
